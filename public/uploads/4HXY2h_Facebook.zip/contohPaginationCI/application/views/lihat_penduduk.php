<!DOCTYPE html>
<html lang="en">
  <?php $this->load->view('includes/heads'); ?>

  <body class="preview" id="top" data-spy="scroll" data-target=".subnav" data-offset="80">
    

    <div class="container">

<br><br><br>
<header class="jumbotron subhead" id="overview">
  <div class="row">
    
    
  </div>
 
</header>
<?php $this->load->view('includes/navbar'); ?>
<section id="typography" class="form-horizontal well">

 


  <fieldset>
<legend>Lihat Detail Penduduk</legend>
  <?php if(isset($penduduk)){
    foreach($penduduk as $row)
    {
    

    ?>
<table class="table table-bordered table-striped table-hover">
  <tr>
 
    <td >ID Penduduk</td>
  
    <td><?php echo $row->id_penduduk ?></td>

  </tr>
  <tr>
 
    <td>Nama</td>
    
    <td><?php echo $row->nama_penduduk ?></td>
    
  </tr>
  <tr>
  
    <td>TTL</td>

    <td><?php echo $row->tempat_lahir ?>, <?php echo $row->tanggal_lahir ?></td>
   
  </tr>
  <tr>
   
    <td>Usia</td>

    <td><?php echo $row->usia ?> </td>
    
  </tr>
  <tr>
 
    <td>Jenis Kelamin</td>

    <td><?php echo $row->jenis_kelamin ?></td>
   
  </tr>
  <tr>
 
    <td>Status</td>

    <td><?php echo $row->status ?></td>
  </tr>
  
  <tr>
  
    <td>Pekerjaan</td>

    <td><?php echo $row->pekerjaan ?></td>
    
  <tr>
 
    <td>RT</td>
    <td><?php echo $row->RT ?></td>
    
  </tr>
  <tr>
 
    <td>RW</td>

    <td><?php echo $row->RW ?></td>
  </tr>
  
 
  <tr>
   
    <td></td>
    <td><?php echo anchor('penduduk/edit_penduduk/'.$row->id_penduduk,'EDIT','class="btn btn-success btn-large"');
    echo " ";
    echo anchor('penduduk/daftar_penduduk','BACK','class="btn btn-primary btn-large"'); 
         ?></td>
  </tr>

</table>
<?php  }
  } ?>
</fieldset>

  
 

</section>
      <hr>

   
<?php $this->load->view('includes/footer'); ?>
    </div>
  

  </body>
</html>