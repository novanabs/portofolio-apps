<!DOCTYPE html>
<html lang="en">
  <?php $this->load->view('includes/heads'); ?>

  <body class="preview" id="top" data-spy="scroll" data-target=".subnav" data-offset="80">
    

    <div class="container">

<br><br><br>
<header class="jumbotron subhead" id="overview">
  <div class="row">
    
    
  </div>
 
</header>
<?php $this->load->view('includes/navbar'); ?>
<section id="typography" class="form-horizontal well">
 <table class="table table-bordered table-striped table-hover">
        <thead>
          <tr>
            <th>ID Penduduk</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Usia</th>
            <th>RT</th>
            <th>RW</th>
           
          </tr>
        </thead>
        <tbody>
         <?php if(isset($penduduk)){
         	foreach($penduduk as $row)
         	{
         		echo '<tr style="text-align:center;">
						<td>'.$row->id_penduduk.'</td>
						<td>'.$row->nama_penduduk.'</td>
						<td>'.$row->jenis_kelamin.'</td>
						<td>'.$row->usia.'</td>
						<td>'.$row->RT.'</td>
						<td>'.$row->RW.'</td>';
						
				echo '</tr>';
         	}
         } ?>
        </tbody>
      
      </table>
      <br>
     <?php echo $link ?> 
</section>

      <hr>

   
<?php $this->load->view('includes/footer'); ?>
    </div>
  

  </body>
</html>