<!DOCTYPE html>
<html lang="en">
  <?php $this->load->view('includes/heads'); ?>

  <body class="preview" id="top" data-spy="scroll" data-target=".subnav" data-offset="80">
    

    <div class="container">

<br><br><br>
<header class="jumbotron subhead" id="overview">
  <div class="row">
    
    
  </div>
 
</header>
<?php $this->load->view('includes/navbar'); ?>
<!-- include() -->
<section id="typography" class="form-horizontal well">


  
 

</section>
      <hr>

   
<?php $this->load->view('includes/footer'); ?>
    </div>
  

  </body>
</html>