   <div class="span4" >
      
      <h4 id="list" >Daftar Menu</h4>
        
      <div class="well" style="padding: 8px 0;">
        <ul class="nav nav-list">
          <li class="nav-header">Management News</li>
          <li class="active"><a href="addnews.php">Add News</a></li>
          <li><a href="#">Look up News</a></li>
          <li class="nav-header">Another list header</li>
          <li><a href="#">Profile</a></li>
          <li><a href="#">Settings</a></li>
          <li class="divider"></li>
          <li><a href="#">Help</a></li>
        </ul>
      </div>
    </div>