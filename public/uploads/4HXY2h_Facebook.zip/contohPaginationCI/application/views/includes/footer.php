    <footer id="footer">
        <p class="pull-right"><a href="#top">Back to top</a></p>
        <div class="links">
          <a href="http://ekkyganteng.com/" onclick="pageTracker._link(this.href); return false;">By EkkyGanteng.com</a> 
    
   
        </div>
       </footer>