<section id="navbar">
  <div class="page-header">
    <h1><a href="">Tutorial CodeIgniter</h1> </a>
    <h3><a href="">Pagination CodeIgniter Menggunakan Bootstrap</a></h3>
  </div>
  <div class="navbar">
    <div class="navbar-inner">
      <div class="container" style="width: auto;">
        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>
        <a class="brand" href="#">Halaman Administrator</a>
        <div class="nav-collapse">
          <ul class="nav">
            <li class="active"><?php echo anchor('penduduk/index','Home') ?></li>
             <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Management Penduduk<b class="caret"></b></a>
            <ul class="dropdown-menu" id="swatch-menu">
              <li><a href="../default">Pilihan Menu : </a></li>
              <li class="divider"></li>
              <!-- <li><?php echo anchor('penduduk/tambah_penduduk','Tambah Data Penduduk') ?></li> -->
              <li><?php echo anchor('penduduk/daftar_penduduk','Lihat Data Penduduk') ?></li>
             
            
            </ul>
          </li>
      

            
              </ul>
           
          
         
          <ul class="nav pull-right">
            <!-- <li><?php echo anchor('penduduk/logout','Logout') ?></li> -->
            
          
          </ul>
        </div><!-- /.nav-collapse -->
      </div>
    </div><!-- /navbar-inner -->
  </div>
</section>