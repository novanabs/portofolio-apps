<!DOCTYPE html>
<html lang="en">
  <?php $this->load->view('includes/heads'); ?>

  <body class="preview" id="top" data-spy="scroll" data-target=".subnav" data-offset="80">
    

    <div class="container">

<br><br><br>
<header class="jumbotron subhead" id="overview">
  <div class="row">
    
    
  </div>
 
</header>
<?php $this->load->view('includes/navbar'); ?>
<section id="forms">
 
<?php $att = array('class'=> 'form-horizontal well'); ?>
<?php echo form_open_multipart('penduduk/proses_edit_penduduk',$att); ?>
  <fieldset>
<legend>Form Tambah Penduduk</legend>
  
<table>
  <tr>
    <td></td>
    <td >ID Penduduk</td>
    <td>:</td>
    <td style="color:red;"> <?php echo form_error('id_penduduk'); ?>
      <input type="text" name="id_penduduk" class="input-large" value="<?php echo $penduduk->id_penduduk ?>" disabled></td>
      <input type="hidden" name="id_penduduk" class="input-large" value="<?php echo $penduduk->id_penduduk ?>">

  </tr>
  <tr>
    <td></td>
    <td>Nama</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('nama_penduduk'); ?>
      <input type="text" name="nama_penduduk" class="input-large" value="<?php echo $penduduk->nama_penduduk ?>"></td>
  </tr>
  <tr>
    <td></td>
    <td>Tempat Lahir</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('tempat_lahir'); ?>
      <input type="text" name="tempat_lahir" class="input-large" value="<?php echo $penduduk->tempat_lahir ?>"></td>
  </tr>
  <tr>
    <td></td>
    <td>Tanggal Lahir</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('tanggal_lahir'); ?>
     <input type="date" name="tanggal_lahir" class="input-large" value="<?php echo $penduduk->tanggal_lahir ?>" datepicker>  </td>
  </tr>
  <tr>
    <td></td>
    <td>Usia</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('usia'); ?>
      <input type="text" name="usia" class="input-large" value="<?php echo $penduduk->usia ?>"></td>
  </tr>
  <tr>
    <td></td>
    <td>Jenis Kelamin</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('jenis_kelamin'); ?>
      <select name="jenis_kelamin">
        <option value="Laki-Laki">Laki - Laki</option>
        <option value="Perempuan">Perempuan</option>
      </select></td>
  </tr>
  

  <tr>
    <td></td>
    <td>Status</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('status'); ?>
      <input type="text" name="status" class="input-large" value="<?php echo $penduduk->status ?>"></td>
  </tr>
  <tr>
    <td></td>
    <td>Pekerjaan</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('pekerjaan'); ?>
      <input type="text" name="pekerjaan" class="input-large" value="<?php echo $penduduk->pekerjaan ?>"></td>
  </tr>
   <tr>
    <td></td>
    <td>RT</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('RT'); ?>
      <input type="text" name="RT" class="input-large" value="<?php echo $penduduk->RT ?>"></td>
  </tr>
   <tr>
    <td></td>
    <td>RW</td>
    <td>:</td>
    <td style="color:red;"><?php echo form_error('RW'); ?>
      <input type="text" name="RW" class="input-large" value="<?php echo $penduduk->RW ?>"></td>
  </tr>
  
 
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td><input type="submit" class="btn btn-primary" value="Submit"></td>
  </tr>

</table>
</fieldset>
</form>
  
 

</section>
      <hr>

   
<?php $this->load->view('includes/footer'); ?>
    </div>
  

  </body>
</html>