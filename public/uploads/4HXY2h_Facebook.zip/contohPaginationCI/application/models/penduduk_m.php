<?php 
class Penduduk_m extends CI_model{


	public function get_data_penduduk($perPage,$uri)
	{
		$this->db->select('*');
		$this->db->limit($perPage, $uri);
		return $this->db->get('penduduk')->result();
	}

	public function get_rows_penduduk()
	{
		return $this->db->query("SELECT * FROM penduduk")->num_rows();
	}
}

 ?>