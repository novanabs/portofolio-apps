<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Penduduk extends CI_controller{

	public function __construct()
	{
		parent::__construct();
		//autoload untuk model
		$this->load->model('penduduk_m');
	}
	//setiap file di php biasa di ganti dengan function di CI.
	public function index()
	{
		$this->load->view('home');
	}


	public function daftar_penduduk()
	{
			$this->load->library('pagination');
			$row = $this->penduduk_m->get_rows_penduduk();
			$config['base_url'] = 'http://localhost/tutorial/contohCRUD/index.php/penduduk/daftar_penduduk';
			$config['total_rows'] = $row;
			$config['per_page'] = 2;
			$config['uri_segment'] = 3;
		    $config['num_links'] = 10;
		    

$config['full_tag_open'] = '<div class="pagination"><ul>';
$config['full_tag_close'] = '</ul></div><!--pagination-->';

$config['first_link'] = '&laquo; ←';
$config['first_tag_open'] = '<li class="arrowleft"><a href="#">';
$config['first_tag_close'] = '</a></li>';

$config['last_link'] = '→ &raquo;';
$config['last_tag_open'] = '<li class="arrowright"><a href="#">';
$config['last_tag_close'] = '</a></li>';

$config['next_link'] = 'Next &rarr;';
$config['next_tag_open'] = '<li class="next page">';
$config['next_tag_close'] = '</li>';

$config['prev_link'] = '&larr; Previous';
$config['prev_tag_open'] = '<li class="prev page">';
$config['prev_tag_close'] = '</li>';

$config['cur_tag_open'] = '<li class="active"><a href="">';
$config['cur_tag_close'] = '</a></li>';

$config['num_tag_open'] = '<li class="page">';
$config['num_tag_close'] = '</li>';



	
			$this->pagination->initialize($config); 	
			$data['penduduk'] = $this->penduduk_m->get_data_penduduk($config['per_page'],$this->uri->segment(3));
			$data['link'] = $this->pagination->create_links();
			$this->load->view('daftar_penduduk',$data);
		
	}



	


 }

 ?>
